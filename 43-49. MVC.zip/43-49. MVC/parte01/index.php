<?

require_once 'libs/app.php';

$app = new App();

?>