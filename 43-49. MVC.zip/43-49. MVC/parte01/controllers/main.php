
<?php

class Main{

    function __construct(){
        echo "<p>Nuevo controlador Main</p>";
    }

    function saludo(){
        echo "<p>Ejecutaste el método Saludo</p>";
    }
}

?>